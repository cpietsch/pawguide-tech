# Copyright 2025-2026 Dimensional Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Mapping, MutableMapping
import dataclasses
import importlib
import inspect
import shutil
import sys
import threading
from typing import TYPE_CHECKING, Any, NamedTuple, cast

from dimos.core.coordination.blueprints import TransportSpec, transport_config_name
from dimos.core.coordination.coordinator_rpc import CoordinatorRPC
from dimos.core.coordination.worker_manager import WorkerManager
from dimos.core.coordination.worker_manager_python import WorkerManagerPython
from dimos.core.global_config import GlobalConfig, global_config
from dimos.core.module import ModuleBase, ModuleSpec, is_module_type
from dimos.core.resource import Resource
from dimos.core.stream import Transport
from dimos.core.transport import (
    LCMTransport,
    PubSubTransport,
    ZenohTransport,
    pLCMTransport,
    pZenohTransport,
)
from dimos.core.transport_factory import make_transport
from dimos.spec.utils import is_spec, spec_annotation_compliance, spec_structural_compliance
from dimos.utils.generic import short_id
from dimos.utils.logging_config import setup_logger
from dimos.utils.safe_thread_map import safe_thread_map

if TYPE_CHECKING:
    from dimos.core.coordination.blueprints import Blueprint, BlueprintAtom
    from dimos.core.rpc_client import ModuleProxy, ModuleProxyProtocol

logger = setup_logger()


class ModuleDescriptor(NamedTuple):
    """Returned by `Coordinator/list_modules` so a remote client can build a proxy."""

    class_name: str
    qualified_path: str
    rpc_names: list[str]
    # RPC topic prefix: the class name, or the instance name for modules
    # deployed under a non-default name. Defaulted so the tuple stays
    # wire-compatible with older daemons.
    rpc_name: str = ""


class ModuleCoordinator(Resource):
    _managers: dict[str, WorkerManager]
    _global_config: GlobalConfig
    _deployed_modules: dict[str, ModuleProxyProtocol]

    def __init__(
        self,
        g: GlobalConfig = global_config,
    ) -> None:
        self._global_config = g
        manager_types: list[type[WorkerManager]] = [WorkerManagerPython]
        self._managers = {cls.deployment_identifier: cls(g=g) for cls in manager_types}
        self._deployed_modules = {}
        self._instance_classes: dict[str, type[ModuleBase]] = {}
        self._deployed_atoms: dict[str, BlueprintAtom] = {}
        self._resolved_module_refs: dict[tuple[str, str], str] = {}
        self._transport_registry: dict[tuple[str, type], Transport[Any]] = {}
        self._class_aliases: dict[type[ModuleBase], type[ModuleBase]] = {}
        self._module_transports: dict[str, dict[str, Transport[Any]]] = {}
        self._started = False
        self._modules_lock = threading.RLock()
        self._coordinator_rpc: CoordinatorRPC | None = None

    def start(self) -> None:
        from dimos.core.o3dpickle import register_picklers

        register_picklers()
        for m in self._managers.values():
            m.start()
        self._started = True

    def stop(self) -> None:
        if self._coordinator_rpc is not None:
            self._coordinator_rpc.stop()
            self._coordinator_rpc = None

        for name, module in reversed(self._deployed_modules.items()):
            logger.info("Stopping module...", module=name)
            try:
                module.stop()
            except Exception:
                logger.error("Error stopping module", module=name, exc_info=True)
            logger.info("Module stopped.", module=name)

        def _stop_manager(m: WorkerManager) -> None:
            try:
                m.stop()
            except Exception:
                logger.error("Error stopping manager", manager=type(m).__name__, exc_info=True)

        safe_thread_map(tuple(self._managers.values()), _stop_manager)

    def start_rpc_service(self) -> None:
        """Expose the coordinator's API as @rpc methods over LCM."""
        if self._coordinator_rpc is not None:
            return
        self._coordinator_rpc = CoordinatorRPC.serve(self)

    @property
    def rpcs(self) -> dict[str, Callable[..., Any]]:
        """Methods exposed via the Coordinator @rpc service."""
        return {
            "ping": self.ping,
            "list_modules": self.list_modules,
            "load_blueprint_by_name": self.load_blueprint_by_name,
            "load_blueprint": self.load_blueprint,
            "restart_module_by_class_name": self.restart_module_by_class_name,
            "restart_module_by_name": self.restart_module_by_name,
        }

    def ping(self) -> str:
        """Used by clients to check if the coordinator is alive and responsive."""
        return "pong"

    def list_modules(self) -> list[ModuleDescriptor]:
        with self._modules_lock:
            descriptors: list[ModuleDescriptor] = []
            for name, cls in self._instance_classes.items():
                qualified = f"{cls.__module__}.{cls.__name__}"
                descriptors.append(
                    ModuleDescriptor(
                        class_name=cls.__name__,
                        qualified_path=qualified,
                        rpc_names=list(cls.rpcs.keys()),
                        rpc_name=_rpc_name(name, cls),
                    )
                )
            return descriptors

    def load_blueprint_by_name(self, name: str) -> None:
        # Avoid circular import.
        from dimos.robot.get_all_blueprints import get_by_name

        self.load_blueprint(get_by_name(name))

    def list_module_names(self) -> list[str]:
        with self._modules_lock:
            return [_rpc_name(name, cls) for name, cls in self._instance_classes.items()]

    def health_check(self) -> bool:
        return all(m.health_check() for m in self._managers.values())

    @property
    def n_modules(self) -> int:
        return len(self._deployed_modules)

    def suppress_console(self) -> None:
        for m in self._managers.values():
            m.suppress_console()

    def deploy(
        self,
        module_class: type[ModuleBase],
        global_config: GlobalConfig = global_config,
        **kwargs: Any,
    ) -> ModuleProxy:
        if not self._managers:
            raise ValueError("Trying to dimos.deploy before the client has started")

        deployed_module = self._managers[module_class.deployment].deploy(
            module_class, global_config, kwargs
        )
        name = kwargs.get("instance_name") or module_class.name
        with self._modules_lock:
            self._deployed_modules[name] = deployed_module
            self._instance_classes[name] = module_class
        return deployed_module  # type: ignore[return-value]

    def deploy_parallel(
        self, module_specs: list[ModuleSpec], blueprint_args: Mapping[str, Mapping[str, Any]]
    ) -> list[ModuleProxy]:
        if not self._managers:
            raise ValueError("Not started")

        # Group specs by deployment type, tracking original indices for reassembly
        indices_by_deployment: dict[str, list[int]] = {}
        specs_by_deployment: dict[str, list[ModuleSpec]] = {}
        for index, spec in enumerate(module_specs):
            # spec = (module_class, global_config, kwargs)
            dep = spec[0].deployment
            indices_by_deployment.setdefault(dep, []).append(index)
            specs_by_deployment.setdefault(dep, []).append(spec)

        results: list[Any] = [None] * len(module_specs)

        def _deploy_group(dep: str) -> None:
            deployed = self._managers[dep].deploy_parallel(specs_by_deployment[dep], blueprint_args)
            for index, module in zip(indices_by_deployment[dep], deployed, strict=True):
                results[index] = module

        try:
            safe_thread_map(list(specs_by_deployment.keys()), _deploy_group)
        except:
            self.stop()
            raise

        with self._modules_lock:
            for (cls, _, kwargs), mod in zip(module_specs, results, strict=True):
                if mod is None:
                    continue
                name = kwargs.get("instance_name") or cls.name
                self._deployed_modules[name] = mod
                self._instance_classes[name] = cls
        return results

    def build_all_modules(self) -> None:
        """Call build() on all deployed modules in parallel.

        build() handles heavy one-time work (docker builds, LFS downloads, etc.)
        with a very long timeout. Must be called after deploy and stream wiring
        but before start_all_modules().
        """
        modules = list(self._deployed_modules.values())
        if not modules:
            raise ValueError("No modules deployed. Call deploy() before build_all_modules().")

        try:
            safe_thread_map(modules, lambda m: m.build())
        except:
            self.stop()
            raise

    def start_all_modules(self) -> None:
        modules = list(self._deployed_modules.values())
        if not modules:
            raise ValueError("No modules deployed. Call deploy() before start_all_modules().")

        safe_thread_map(modules, lambda m: m.start())

        self._send_on_system_modules()

    def _resolve_class(self, cls: type[ModuleBase]) -> type[ModuleBase]:
        return self._class_aliases.get(cls, cls)

    def _instance_keys_of(self, module: type[ModuleBase]) -> list[str]:
        cls = self._resolve_class(module)
        return [n for n, c in self._instance_classes.items() if self._resolve_class(c) is cls]

    def _resolve_instance_key(self, module: type[ModuleBase] | str) -> str:
        """Resolve a module class or instance name to the deployed instance name."""
        if isinstance(module, str):
            if module not in self._deployed_modules:
                raise ValueError(f"{module!r} is not deployed")
            return module
        names = self._instance_keys_of(module)
        if not names:
            raise ValueError(f"{module.__name__} is not deployed")
        if len(names) > 1:
            raise ValueError(
                f"Multiple instances of {module.__name__} are deployed "
                f"({', '.join(sorted(names))}); pass the instance name."
            )
        return names[0]

    def get_instance(self, module: type[ModuleBase] | str) -> ModuleProxy:
        if isinstance(module, str):
            return self._deployed_modules.get(module)  # type: ignore[return-value]
        names = self._instance_keys_of(module)
        if len(names) > 1:
            raise ValueError(
                f"Multiple instances of {module.__name__} are deployed "
                f"({', '.join(sorted(names))}); pass the instance name."
            )
        return self._deployed_modules.get(names[0]) if names else None  # type: ignore[return-value]

    def _send_on_system_modules(self) -> None:
        modules = list(self._deployed_modules.values())
        for module in modules:
            if hasattr(module, "on_system_modules"):
                module.on_system_modules(modules)

    def _connect_streams(
        self, blueprint: Blueprint, transports: Mapping[tuple[str, type], Transport[Any]]
    ) -> None:
        streams: dict[tuple[str, type], list[tuple[str, str]]] = defaultdict(list)

        for bp in blueprint.active_blueprints:
            for conn in bp.streams:
                remapped_name = blueprint.remapping_map.get((bp.name, conn.name), conn.name)
                if isinstance(remapped_name, str):
                    streams[remapped_name, conn.type].append((bp.name, conn.name))

        for remapped_name, stream_type in streams.keys():
            key = (remapped_name, stream_type)
            if key in self._transport_registry:
                transport = self._transport_registry[key]
            else:
                transport = transports.get(key) or _get_transport_for(
                    blueprint, remapped_name, stream_type
                )
            self._transport_registry[key] = transport
            for instance_key, original_name in streams[key]:
                instance = self.get_instance(instance_key)  # type: ignore[assignment]
                instance.set_transport(original_name, transport)  # type: ignore[union-attr]
                self._module_transports.setdefault(instance_key, {})[original_name] = transport
                logger.info(
                    "Transport",
                    name=remapped_name,
                    original_name=original_name,
                    topic=str(getattr(transport, "topic", None)),
                    type=f"{stream_type.__module__}.{stream_type.__qualname__}",
                    module=instance_key,
                    transport=transport.__class__.__name__,
                )

    @classmethod
    def build(
        cls,
        blueprint: Blueprint,
        blueprint_args: MutableMapping[str, Any] | None = None,
    ) -> ModuleCoordinator:
        logger.info("Building the blueprint")
        global_config.update(**dict(blueprint.global_config_overrides))
        blueprint_args = blueprint_args or {}
        if "g" in blueprint_args:
            global_config.update(**blueprint_args.pop("g"))
        transport_overrides = blueprint_args.pop("transports", None) or {}
        transports = _materialize_transports(blueprint, transport_overrides)

        _run_configurators(blueprint)
        _check_requirements(blueprint)
        _verify_no_name_conflicts(blueprint)

        logger.info("Starting the modules")
        coordinator = cls(g=global_config)
        coordinator.start()

        _deploy_all_modules(blueprint, coordinator, global_config, blueprint_args)
        coordinator._connect_streams(blueprint, transports)
        _connect_module_refs(blueprint, coordinator)

        coordinator.build_all_modules()
        coordinator.start_all_modules()

        _log_blueprint_graph(blueprint, coordinator)

        return coordinator

    def load_blueprint(
        self,
        blueprint: Blueprint,
        blueprint_args: MutableMapping[str, Mapping[str, Any]] | None = None,
    ) -> None:
        """Load a blueprint into an already-running coordinator.

        Deploys, wires, builds and starts the modules described by *blueprint*.
        Workers are added automatically based on the blueprint's ``n_workers``
        global-config override (additive).
        """
        if not self._started:
            raise RuntimeError("ModuleCoordinator not started; call start() first")

        with self._modules_lock:
            self._load_blueprint(blueprint, blueprint_args)

    def _load_blueprint(
        self,
        blueprint: Blueprint,
        blueprint_args: MutableMapping[str, Mapping[str, Any]] | None = None,
    ) -> None:
        # Apply config overrides.
        self._global_config.update(**dict(blueprint.global_config_overrides))
        blueprint_args = blueprint_args or {}
        if "g" in blueprint_args:
            self._global_config.update(**blueprint_args.pop("g"))
        transport_overrides = blueprint_args.pop("transports", None) or {}
        transports = _materialize_transports(blueprint, transport_overrides)

        # Scale worker pool.
        n_extra = int(blueprint.global_config_overrides.get("n_workers", 0))
        python_wm = cast("WorkerManagerPython", self._managers["python"])
        if n_extra:
            python_wm.add_workers(n_extra)
        if not python_wm.workers and blueprint.active_blueprints:
            python_wm.add_workers(1)

        _run_configurators(blueprint)
        _check_requirements(blueprint)
        _verify_no_name_conflicts(blueprint)
        _verify_no_conflicts_with_existing(blueprint, self._transport_registry)

        # Reject duplicate modules.
        for bp in blueprint.active_blueprints:
            if bp.name in self._deployed_modules:
                raise ValueError(
                    f"{bp.name} is already deployed; cannot load the same module twice"
                )

        before = set(self._deployed_modules)
        existing_atoms = tuple(
            atom for name in before if (atom := self._deployed_atoms.get(name)) is not None
        )
        existing_classes = {self._instance_classes[name] for name in before}

        _deploy_all_modules(blueprint, self, self._global_config, blueprint_args)
        self._connect_streams(blueprint, transports)
        _connect_module_refs(
            blueprint,
            self,
            existing_atoms=existing_atoms,
            existing_modules=existing_classes,
        )

        new_modules = [
            proxy for name, proxy in self._deployed_modules.items() if name not in before
        ]

        if new_modules:
            safe_thread_map(new_modules, lambda m: m.build())
            safe_thread_map(new_modules, lambda m: m.start())

        self._send_on_system_modules()

    def load_module(
        self,
        module_class: type[ModuleBase],
        blueprint_args: MutableMapping[str, Mapping[str, Any]] | None = None,
    ) -> None:
        self.load_blueprint(module_class.blueprint(**blueprint_args or {}))

    def unload_module(self, module: type[ModuleBase] | str) -> None:
        """Stop and tear down a single deployed module.

        Accepts a module class (must have exactly one deployed instance) or an
        instance name. Removes the module from coordinator state, stops its
        worker-side instance, and shuts down the worker process if it becomes
        empty. Stream transports and other modules' references are left
        intact — callers that expect the module to come back (e.g.
        ``restart_module``) are responsible for rewiring.
        """
        with self._modules_lock:
            self._unload_module(module)

    def _unload_module(self, module: type[ModuleBase] | str) -> None:
        name = self._resolve_instance_key(module)
        module_class = self._instance_classes[name]
        if module_class.deployment != "python":
            raise NotImplementedError(
                f"unload_module only supports python deployment, got {module_class.deployment!r}"
            )

        proxy = self._deployed_modules[name]

        try:
            proxy.stop()
        except Exception:
            logger.error(
                "Error stopping module during unload",
                module=name,
                exc_info=True,
            )

        python_wm = cast("WorkerManagerPython", self._managers["python"])
        try:
            python_wm.undeploy(proxy)
        except Exception:
            logger.error(
                "Error undeploying module from worker",
                module=name,
                exc_info=True,
            )

        del self._deployed_modules[name]
        del self._instance_classes[name]
        self._deployed_atoms.pop(name, None)
        self._module_transports.pop(name, None)
        if not any(c is module_class for c in self._instance_classes.values()):
            self._class_aliases = {
                k: v for k, v in self._class_aliases.items() if v is not module_class
            }
        self._resolved_module_refs = {
            key: target
            for key, target in self._resolved_module_refs.items()
            if key[0] != name and target != name
        }

    def restart_module_by_class_name(
        self,
        class_name: str,
        *,
        reload_source: bool = True,
    ) -> None:
        with self._modules_lock:
            names = [n for n, c in self._instance_classes.items() if c.__name__ == class_name]
            if len(names) > 1:
                raise ValueError(
                    f"Multiple instances of {class_name!r} are deployed "
                    f"({', '.join(sorted(names))}); use restart_module_by_name."
                )
            if names:
                self._restart_module(names[0], reload_source=reload_source)
                return
        raise ValueError(f"No deployed module with class name {class_name!r}")

    def restart_module_by_name(
        self,
        name: str,
        *,
        reload_source: bool = True,
    ) -> None:
        with self._modules_lock:
            self._restart_module(name, reload_source=reload_source)

    def restart_module(
        self,
        module: type[ModuleBase] | str,
        *,
        reload_source: bool = True,
    ) -> ModuleProxyProtocol:
        """Restart a single deployed module in place.

        Accepts a module class (must have exactly one deployed instance) or an
        instance name. Unloads the module, optionally reloads its source file
        via ``importlib.reload`` so edited code is picked up, then redeploys it
        onto a fresh worker process, reconnects its streams to the existing
        transports, and re-injects the new proxy into every other module that
        held a reference to it.
        """
        with self._modules_lock:
            return self._restart_module(module, reload_source=reload_source)

    def _restart_module(
        self,
        module: type[ModuleBase] | str,
        *,
        reload_source: bool = True,
    ) -> ModuleProxyProtocol:
        name = self._resolve_instance_key(module)
        module_class = self._instance_classes[name]
        if module_class.deployment != "python":
            raise NotImplementedError(
                f"restart_module only supports python deployment, got {module_class.deployment!r}"
            )

        old_atom = self._deployed_atoms[name]
        kwargs = dict(old_atom.kwargs)
        saved_transports = dict(self._module_transports.get(name, {}))
        inbound_refs = [
            (consumer, ref_name)
            for (consumer, ref_name), target in self._resolved_module_refs.items()
            if target == name
        ]
        outbound_refs = [
            (ref_name, target)
            for (consumer, ref_name), target in self._resolved_module_refs.items()
            if consumer == name
        ]

        self.unload_module(name)

        if reload_source:
            source_mod = sys.modules.get(module_class.__module__)
            if source_mod is None:
                source_mod = importlib.import_module(module_class.__module__)
            importlib.reload(source_mod)
            new_class = cast("type[ModuleBase]", getattr(source_mod, module_class.__name__))
        else:
            new_class = module_class

        if new_class is not module_class:
            for old_cls in list(self._class_aliases):
                if self._class_aliases[old_cls] is module_class:
                    self._class_aliases[old_cls] = new_class
            self._class_aliases[module_class] = new_class

        python_wm = cast("WorkerManagerPython", self._managers["python"])
        new_proxy = python_wm.deploy_fresh(new_class, self._global_config, kwargs)
        self._deployed_modules[name] = new_proxy
        self._instance_classes[name] = new_class

        new_bp = new_class.blueprint(**kwargs)
        new_atom = new_bp.active_blueprints[0]
        if old_atom.instance_name is not None:
            new_atom = dataclasses.replace(new_atom, instance_name=old_atom.instance_name)
        self._deployed_atoms[name] = new_atom

        for stream_ref in new_atom.streams:
            transport = saved_transports.get(stream_ref.name)
            if transport is not None:
                new_proxy.set_transport(stream_ref.name, transport)
        self._module_transports[name] = {
            s.name: t for s in new_atom.streams if (t := saved_transports.get(s.name)) is not None
        }

        for consumer_key, ref_name in inbound_refs:
            consumer_proxy = self._deployed_modules.get(consumer_key)
            if consumer_proxy is None:
                continue
            setattr(consumer_proxy, ref_name, new_proxy)
            consumer_proxy.set_module_ref(ref_name, new_proxy)  # type: ignore[attr-defined]
            self._resolved_module_refs[consumer_key, ref_name] = name

        for ref_name, target_key in outbound_refs:
            target_proxy = self._deployed_modules.get(target_key)
            if target_proxy is None:
                continue
            setattr(new_proxy, ref_name, target_proxy)
            new_proxy.set_module_ref(ref_name, target_proxy)  # type: ignore[attr-defined]
            self._resolved_module_refs[name, ref_name] = target_key

        new_proxy.build()
        new_proxy.start()

        self._send_on_system_modules()

        return new_proxy

    def loop(self) -> None:
        stop = threading.Event()
        try:
            stop.wait()
        except KeyboardInterrupt:
            return
        finally:
            self.stop()


def _rpc_name(instance_key: str, cls: type[ModuleBase]) -> str:
    """The module's RPC topic prefix: class name unless an instance name is set."""
    return cls.__name__ if instance_key == cls.name else instance_key


def _all_name_types(blueprint: Blueprint) -> set[tuple[str, type]]:
    result = set()
    for bp in blueprint.active_blueprints:
        for conn in bp.streams:
            remapped_name = blueprint.remapping_map.get((bp.name, conn.name), conn.name)
            if isinstance(remapped_name, str):
                result.add((remapped_name, conn.type))
    return result


def _is_name_unique(blueprint: Blueprint, name: str) -> bool:
    return sum(1 for n, _ in _all_name_types(blueprint) if n == name) == 1


def _get_transport_for(blueprint: Blueprint, name: str, stream_type: type) -> PubSubTransport[Any]:
    topic = f"/{name}" if _is_name_unique(blueprint, name) else f"/{short_id()}"
    return make_transport(topic, stream_type)


def _coerce_transport_to_backend(transport: Transport[Any]) -> Transport[Any]:
    """Rebuild an explicitly-mapped LCM/Zenoh transport for the active backend.

    Blueprints pin specific channels in their `transport_map` with e.g. `LCMTransport.spec(
    "/cmd_vel", Twist)`. So the global transport switch reaches those too, rebuild the plain
    LCM<->Zenoh pair via the factory when it doesn't match `global_config.transport`. Deliberate
    non-default choices (`JpegLcmTransport`, SHM, ROS, DDS, WebRTC, ...) are exact-type-checked
    out and left untouched.
    """
    want = global_config.transport
    is_pickled = type(transport) in (pLCMTransport, pZenohTransport)
    is_lcm = type(transport) in (LCMTransport, pLCMTransport)
    is_zenoh = type(transport) in (ZenohTransport, pZenohTransport)
    if not isinstance(transport, PubSubTransport) or not (
        (want == "zenoh" and is_lcm) or (want == "lcm" and is_zenoh)
    ):
        return transport

    if is_pickled:
        raw, msg_type = transport.topic, None
    else:
        raw, msg_type = transport.topic.topic, transport.topic.lcm_type
    # Strip the Zenoh 'dimos/' namespace (if present) back to the logical name.
    # The factory re-applies the right prefix for the target backend.
    logical = raw[len("dimos/") :] if raw.startswith("dimos/") else raw
    return make_transport(logical, msg_type)


def _materialize_transports(
    blueprint: Blueprint, overrides: Mapping[str, Mapping[str, Any]]
) -> dict[tuple[str, type], Transport[Any]]:
    """Build the blueprint's declared transports, merging CLI/env config overrides.

    WebRTC transports get a freshly constructed provider config from the
    resolved ``transports.<name>.*`` overrides; everything else builds from the
    spec as-is, then gets coerced to the active pubsub backend. Returns
    ready-to-use instances pickled into module workers.
    """
    materialized: dict[tuple[str, type], Transport[Any]] = {}
    for key, spec in blueprint.transport_map.items():
        if not isinstance(spec, TransportSpec):
            # Plain transport instance pinned directly in the blueprint — use
            # as-is (modulo the global lcm/zenoh backend switch).
            materialized[key] = _coerce_transport_to_backend(spec)
            continue
        config = None
        config_cls = spec.config_cls
        if config_cls is not None:
            # Config-field kwargs pinned on the spec
            spec_fields = {k: v for k, v in spec.kwargs.items() if k in config_cls.model_fields}
            sub = overrides.get(transport_config_name(config_cls), {})
            config = config_cls(**{**spec_fields, **sub})
        materialized[key] = _coerce_transport_to_backend(spec.build(config=config))
    return materialized


def _verify_no_name_conflicts(blueprint: Blueprint) -> None:
    name_to_types: dict[Any, set[type]] = defaultdict(set)
    name_to_modules: dict[Any, list[tuple[type, type]]] = defaultdict(list)

    for bp in blueprint.active_blueprints:
        for conn in bp.streams:
            stream_name = blueprint.remapping_map.get((bp.name, conn.name), conn.name)
            name_to_types[stream_name].add(conn.type)
            name_to_modules[stream_name].append((bp.module, conn.type))

    conflicts: dict[Any, dict[type, list[type]]] = {}
    for conn_name, types in name_to_types.items():
        if len(types) > 1:
            modules_by_type: dict[type, list[type]] = defaultdict(list)
            for module, conn_type in name_to_modules[conn_name]:
                modules_by_type[conn_type].append(module)
            conflicts[conn_name] = modules_by_type

    if not conflicts:
        return

    error_lines = ["Blueprint cannot start because there are conflicting streams."]
    for name, modules_by_type in conflicts.items():
        type_entries = []
        for conn_type, modules in modules_by_type.items():
            for module in modules:
                type_str = f"{conn_type.__module__}.{conn_type.__name__}"
                module_str = module.__name__
                type_entries.append((type_str, module_str))
        if len(type_entries) >= 2:
            locations = ", ".join(f"{type_} in {module}" for type_, module in type_entries)
            error_lines.append(f"    - '{name}' has conflicting types. {locations}")

    raise ValueError("\n".join(error_lines))


def _verify_no_conflicts_with_existing(
    blueprint: Blueprint,
    existing_registry: dict[tuple[str, type], Transport[Any]],
) -> None:
    """Check that a new blueprint's streams don't conflict with already-registered transports."""
    if not existing_registry:
        return

    existing_names: dict[str, set[type]] = defaultdict(set)
    for name, stream_type in existing_registry:
        existing_names[name].add(stream_type)

    for bp in blueprint.active_blueprints:
        for conn in bp.streams:
            remapped_name = blueprint.remapping_map.get((bp.name, conn.name), conn.name)
            if isinstance(remapped_name, str) and remapped_name in existing_names:
                for existing_type in existing_names[remapped_name]:
                    if existing_type != conn.type:
                        raise ValueError(
                            f"Stream '{remapped_name}' in {bp.module.__name__} has type "
                            f"{conn.type.__module__}.{conn.type.__name__} but an existing "
                            f"transport uses {existing_type.__module__}.{existing_type.__name__}"
                        )


def _run_configurators(blueprint: Blueprint) -> None:
    from dimos.protocol.service.system_configurator.base import configure_system
    from dimos.protocol.service.system_configurator.lcm_config import lcm_configurators

    lcm_checks = lcm_configurators() if global_config.transport == "lcm" else []
    configurators = [*lcm_checks, *blueprint.configurator_checks]

    try:
        configure_system(configurators)
    except SystemExit:
        labels = [type(c).__name__ for c in configurators]
        print(
            f"Required system configuration was declined: {', '.join(labels)}",
            file=sys.stderr,
        )
        sys.exit(1)


def _check_requirements(blueprint: Blueprint) -> None:
    errors = []
    red = "\033[31m"
    reset = "\033[0m"

    for check in blueprint.requirement_checks:
        error = check()
        if error:
            errors.append(error)

    if errors:
        for error in errors:
            print(f"{red}Error: {error}{reset}", file=sys.stderr)
        sys.exit(1)


def _deploy_all_modules(
    blueprint: Blueprint,
    module_coordinator: ModuleCoordinator,
    gc: GlobalConfig,
    blueprint_args: Mapping[str, Mapping[str, Any]],
) -> None:
    module_specs: list[ModuleSpec] = []
    for bp in blueprint.active_blueprints:
        kwargs = bp.kwargs.copy()
        if bp.instance_name is not None:
            kwargs.setdefault("instance_name", bp.instance_name)
        module_specs.append((bp.module, gc, kwargs))

    module_coordinator.deploy_parallel(module_specs, blueprint_args)

    for bp in blueprint.active_blueprints:
        module_coordinator._deployed_atoms[bp.name] = bp


def _ref_msg(module_name: str, ref: object, spec_name: str, detail: str) -> str:
    return (
        f"{module_name} has a module reference ({ref}) requesting a module that "
        f"satisfies the {spec_name} spec. {detail}"
    )


def _atom_namespace(instance_name: str) -> str:
    return instance_name.rsplit("/", 1)[0] if "/" in instance_name else ""


def _namespace_levels(consumer_namespace: str) -> list[str]:
    """Ref search order: the consumer's namespace, enclosing ones, then global."""
    levels = []
    namespace = consumer_namespace
    while namespace:
        levels.append(namespace)
        namespace = _atom_namespace(namespace)
    levels.append("")
    return levels


def _resolve_single_ref(
    bp: Any,
    module_ref: Any,
    spec: Any,
    blueprint: Blueprint,
    disabled_set: set[type],
    existing_atoms: tuple[BlueprintAtom, ...] = (),
    existing_modules: set[type[ModuleBase]] | None = None,
) -> Any:
    """Resolve a module ref to its provider.

    Returns an instance name, a module type (provider outside the blueprint),
    a ``DisabledModuleProxy``, or *None* (skip).
    """
    from dimos.core.coordination.blueprints import BlueprintAtom, DisabledModuleProxy

    m = bp.module.__name__
    s = module_ref.spec.__name__
    is_class_ref = is_module_type(spec)

    def satisfies(cls: type) -> bool:
        return cls is spec if is_class_ref else spec_structural_compliance(cls, spec)

    def module_of(candidate: Any) -> type[ModuleBase]:
        return candidate.module if isinstance(candidate, BlueprintAtom) else candidate

    def result_of(candidate: Any) -> Any:
        return candidate.name if isinstance(candidate, BlueprintAtom) else candidate

    def display(candidate: Any) -> str:
        return candidate.name if isinstance(candidate, BlueprintAtom) else candidate.__name__

    active_atoms = tuple(blueprint.active_blueprints)
    atom_candidates = active_atoms + existing_atoms
    atom_module_set = {candidate.module for candidate in atom_candidates}

    # Search the consumer's own namespace first so a per-robot consumer binds
    # to its own robot's provider instead of colliding with the other robots'.
    possible: list[Any] = []
    for level in _namespace_levels(_atom_namespace(bp.name)):
        possible = [
            other
            for other in atom_candidates
            if other != bp and _atom_namespace(other.name) == level and satisfies(other.module)
        ]
        if level == "" and existing_modules:
            possible += [
                mod_cls
                for mod_cls in existing_modules
                if mod_cls != bp.module and mod_cls not in atom_module_set and satisfies(mod_cls)
            ]
        if possible:
            break

    if not possible:
        if module_ref.optional:
            return None
        if is_class_ref:
            # The provider class is not in the blueprint; keep the class and
            # let get_instance resolve it (legacy behavior, possibly None).
            return spec
        disabled = next(
            (
                other.module
                for other in blueprint.blueprints
                if other.module in disabled_set and spec_structural_compliance(other.module, spec)
            ),
            None,
        )
        if disabled is not None:
            logger.warning(
                "Module ref unsatisfied because provider is disabled; installing no-op proxy",
                ref=module_ref.name,
                consumer=m,
                disabled_provider=disabled.__name__,
                spec=s,
            )
            return DisabledModuleProxy(s)
        raise Exception(_ref_msg(m, module_ref, s, "No module met that spec."))

    valid = [c for c in possible if is_class_ref or spec_annotation_compliance(module_of(c), spec)]

    if len(possible) == 1:
        if not valid:
            logger.warning(
                _ref_msg(
                    m,
                    module_ref,
                    s,
                    f"{display(possible[0])} met the spec structurally but had "
                    f"annotation mismatches.\nPlease either change the {s} spec "
                    f"or the {module_of(possible[0]).__name__} module.",
                )
            )
        return result_of(possible[0])

    if len(valid) == 1:
        return result_of(valid[0])

    if len(valid) > 1:
        raise Exception(
            _ref_msg(
                m,
                module_ref,
                s,
                f"Multiple modules met that spec: {[display(c) for c in valid]}.\n"
                f"To fix this use .remappings, for example:\n"
                f"    autoconnect(...).remappings([ ({m}, {module_ref.name!r}, "
                f"<ModuleThatHasTheRpcCalls>) ])",
            )
        )

    names = ", ".join(display(c) for c in possible)
    raise Exception(
        _ref_msg(
            m,
            module_ref,
            s,
            f"Some modules ({names}) met the spec structurally but had annotation mismatches.",
        )
    )


def _connect_module_refs(
    blueprint: Blueprint,
    module_coordinator: ModuleCoordinator,
    existing_atoms: tuple[BlueprintAtom, ...] = (),
    existing_modules: set[type[ModuleBase]] | None = None,
) -> None:
    from dimos.core.coordination.blueprints import DisabledModuleProxy
    from dimos.core.module import is_module_type
    from dimos.core.rpc_client import AsyncSpecProxy

    mod_and_mod_ref_to_proxy = {
        (instance_key, name): replacement
        for (instance_key, name), replacement in blueprint.remapping_map.items()
        if is_spec(replacement) or is_module_type(replacement)
    }

    # Track the consumer's declared spec for each ref so we can wrap the proxy
    # below if the spec contains async-declared methods.
    declared_spec: dict[tuple[str, str], Any] = {}

    disabled_ref_proxies: dict[tuple[str, str], DisabledModuleProxy] = {}
    disabled_set = set(blueprint.disabled_modules_tuple)

    for bp in blueprint.active_blueprints:
        for module_ref in bp.module_refs:
            declared_spec[bp.name, module_ref.name] = module_ref.spec
            spec = mod_and_mod_ref_to_proxy.get((bp.name, module_ref.name), module_ref.spec)

            result = _resolve_single_ref(
                bp,
                module_ref,
                spec,
                blueprint,
                disabled_set,
                existing_atoms,
                existing_modules,
            )
            if result is None:
                mod_and_mod_ref_to_proxy.pop((bp.name, module_ref.name), None)
                continue
            if isinstance(result, DisabledModuleProxy):
                disabled_ref_proxies[bp.name, module_ref.name] = result
                mod_and_mod_ref_to_proxy.pop((bp.name, module_ref.name), None)
            else:
                mod_and_mod_ref_to_proxy[bp.name, module_ref.name] = result

    for (base_key, ref_name), target in mod_and_mod_ref_to_proxy.items():
        base_instance = module_coordinator.get_instance(base_key)
        target_instance: Any = module_coordinator.get_instance(target)  # type: ignore[arg-type]
        async_methods = _async_methods_of_spec(declared_spec.get((base_key, ref_name)))
        if async_methods:
            target_instance = AsyncSpecProxy(target_instance, async_methods)
        setattr(base_instance, ref_name, target_instance)
        base_instance.set_module_ref(ref_name, target_instance)
        if isinstance(target, str):
            module_coordinator._resolved_module_refs[base_key, ref_name] = target
        else:
            target_keys = module_coordinator._instance_keys_of(cast("type[ModuleBase]", target))
            if target_keys:
                module_coordinator._resolved_module_refs[base_key, ref_name] = target_keys[0]

    for (base_key, ref_name), proxy in disabled_ref_proxies.items():
        base_instance = module_coordinator.get_instance(base_key)
        setattr(base_instance, ref_name, proxy)
        base_instance.set_module_ref(ref_name, cast("Any", proxy))


def _async_methods_of_spec(spec: Any) -> frozenset[str]:
    if not is_spec(spec):
        return frozenset()
    names: set[str] = set()
    for cls in spec.__mro__:
        if cls is object:
            continue
        for attr_name, value in vars(cls).items():
            if attr_name.startswith("_"):
                continue
            if inspect.iscoroutinefunction(value):
                names.add(attr_name)
    return frozenset(names)


def _log_blueprint_graph(blueprint: Blueprint, module_coordinator: ModuleCoordinator) -> None:
    """Log the module graph to Rerun if a RerunBridgeModule is active."""
    from dimos.visualization.rerun.bridge import RerunBridgeModule

    if not any(bp.module is RerunBridgeModule for bp in blueprint.active_blueprints):
        return

    if not shutil.which("dot"):
        logger.info(
            "graphviz not found, skipping blueprint graph. Install: sudo apt install graphviz"
        )
        return

    try:
        from dimos.core.introspection.blueprint.dot import render

        dot_code = render(blueprint)
        module_names = [bp.module.__name__ for bp in blueprint.active_blueprints]
        bridge = module_coordinator.get_instance(RerunBridgeModule)  # type: ignore[arg-type]
        bridge.log_blueprint_graph(dot_code, module_names)
    except Exception:
        logger.error("Failed to log blueprint graph to Rerun", exc_info=True)
