# Copyright 2025-2026 Dimensional Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""ZED camera compatibility layer and SDK detection."""

from pathlib import Path

from dimos.msgs.sensor_msgs.CameraInfo import CalibrationProvider

try:
    import pyzed.sl  # noqa: F401

    # This awkwardness is needed as pytest implicitly imports this to collect
    # the test in this directory.
    HAS_ZED_SDK = True
except ImportError:
    HAS_ZED_SDK = False

if HAS_ZED_SDK:
    from dimos.hardware.sensors.camera.zed.camera import (
        ZEDCamera as ZEDCamera,
        ZEDModule as ZEDModule,
    )
else:
    # Provide stub classes when SDK is not available
    _ZED_ERR = (
        "ZED SDK not installed. Please install pyzed package to use ZED camera functionality."
    )

    class ZEDCamera:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
            raise ImportError(_ZED_ERR)

        @classmethod
        def blueprint(cls, *args: object, **kwargs: object) -> None:
            raise ImportError(_ZED_ERR)

    class ZEDModule:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
            raise ImportError(_ZED_ERR)


# Set up camera calibration provider (always available)
CALIBRATION_DIR = Path(__file__).parent
CameraInfo = CalibrationProvider(CALIBRATION_DIR)
