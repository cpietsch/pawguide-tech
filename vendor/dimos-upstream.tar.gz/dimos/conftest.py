# Copyright 2025-2026 Dimensional Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from contextlib import suppress
import hashlib
import os
import platform
import tempfile
import threading
import time
import uuid

# Tag every pytest descendant so a sidecar watchdog can sweep strays (dimsim, rerun, etc).
DIMOS_PYTEST_RUN_ID_ENV = "DIMOS_PYTEST_RUN_ID"
_worker = os.environ.get("PYTEST_XDIST_WORKER")
if not _worker:
    os.environ[DIMOS_PYTEST_RUN_ID_ENV] = f"pytest-{uuid.uuid4().hex[:16]}"

# Pin every pytest session to its own LCM bus *before* any dimos module is
# imported (``LCMConfig`` captures ``LCM_DEFAULT_URL`` at import time), so
# messages from processes outside the session (a dev ``dimos`` daemon, a
# leaked DimSim bridge, a concurrent pytest run) can't leak into
# subscribe_all/pattern tests. It has to be an env var (not just a fixture)
# because subprocesses spawned by tests (``ModuleCoordinator`` workers, the
# DimSim Deno bridge) create their own LCM instances and inherit our env.
#
# Buckets are seeded with the session run id so concurrent sessions on one
# machine can't collide. xdist workers mix in the worker name, and also get
# a per-worker MCP port (``GlobalConfig`` captures ``MCP_PORT``) and state
# dir (``run_registry`` captures ``XDG_STATE_HOME``), which only collide
# between parallel workers. Exporting ``LCM_DEFAULT_URL`` yourself opts a
# single-worker session out of the isolation, deliberately joining it to an
# external bus.


def _lcm_bucket(seed: str) -> int:
    return int.from_bytes(hashlib.blake2b(seed.encode(), digest_size=2).digest(), "big") % 5000


_run_id = os.environ[DIMOS_PYTEST_RUN_ID_ENV]
if _worker:
    _BUCKET = _lcm_bucket(f"{_run_id}:{_worker}")
    os.environ["LCM_DEFAULT_URL"] = f"udpm://239.255.76.67:{7700 + _BUCKET}?ttl=0"
    os.environ["MCP_PORT"] = str(20000 + _BUCKET)
    os.environ["XDG_STATE_HOME"] = tempfile.mkdtemp(prefix=f"dimos-test-state-{_worker}-")
elif "LCM_DEFAULT_URL" not in os.environ:
    os.environ["LCM_DEFAULT_URL"] = f"udpm://239.255.76.67:{7700 + _lcm_bucket(_run_id)}?ttl=0"

# Raise the open-file limit. Each LCM transport opens at least one
# multicast socket; with pytest-xdist workers running many in parallel,
# the macOS default soft cap (~256) gets exhausted and tests fail with
# `OSError: [Errno 24] Too many open files`. The autoconf path normally
# bumps this via `MaxFileConfiguratorMacOS` (sudo launchctl), but we
# disable autoconf for tests, so do it directly here against the per-
# process limit (no sudo required up to the hard cap).
with suppress(ImportError, ValueError, OSError):
    import resource

    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    target = min(65536, hard)
    if soft < target:
        resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))

from dotenv import load_dotenv
import pytest
import tqdm

from dimos.core.coordination.module_coordinator import ModuleCoordinator
from dimos.core.coordination.process_lifecycle import spawn_watchdog
from dimos.utils.testing.waiting import retry_until as _retry_until, wait_until as _wait_until

# The first tqdm bar constructed in the process spawns a TMonitor daemon thread that lives until
# interpreter exit. If that first bar happens inside a test, monitor_threads flags it as a leak. The
# monitor only re-tunes miniters for smooth interactive rendering, so disable it for tests.
tqdm.tqdm.monitor_interval = 0

load_dotenv()


def _has_ros() -> bool:
    try:
        import rclpy  # noqa: F401

        return True
    except ImportError:
        return False


def _is_macos() -> bool:
    return platform.system() == "Darwin"


def pytest_configure(config):
    config.addinivalue_line(
        "markers",
        "self_hosted: tests that need the self-hosted runner (LFS, ROS, CUDA, etc.)",
    )
    config.addinivalue_line("markers", "mujoco: tests which open mujoco")
    config.addinivalue_line(
        "markers", "self_hosted_large: tests that need a high-memory self-hosted runner"
    )
    config.addinivalue_line("markers", "skipif_in_ci: skip when CI env var is set")
    config.addinivalue_line("markers", "skipif_no_openai: skip when OPENAI_API_KEY is not set")
    config.addinivalue_line("markers", "skipif_no_alibaba: skip when ALIBABA_API_KEY is not set")
    config.addinivalue_line("markers", "skipif_no_ros: skip when ROS dependencies are not present")
    config.addinivalue_line("markers", "skipif_macos_bug: skip known-buggy tests on macOS")
    config.addinivalue_line("markers", "skipif_macos: skip tests not intended to run on macOS")
    config.addinivalue_line(
        "markers", "skipif_aarch64: skip tests not intended to run on aarch64 (Linux ARM)"
    )

    if config.pluginmanager.hasplugin("_cov"):
        os.environ["COVERAGE_PROCESS_START"] = str(config.rootpath / "pyproject.toml")

    # Only spawn on the controller, without doing it on xdist workers.
    if not hasattr(config, "workerinput"):
        spawn_watchdog(
            os.environ[DIMOS_PYTEST_RUN_ID_ENV],
            env_var=DIMOS_PYTEST_RUN_ID_ENV,
        )


@pytest.fixture(scope="session")
def mcp_port() -> int:
    """The MCP server port pinned for this xdist worker (or the default)."""
    return int(os.environ.get("MCP_PORT", "9990"))


@pytest.fixture(scope="session")
def mcp_url(mcp_port: int) -> str:
    """The MCP server URL pinned for this xdist worker (or the default)."""
    return f"http://localhost:{mcp_port}/mcp"


@pytest.fixture(scope="session")
def lcm_url() -> str:
    """The LCM bus URL pinned for this xdist worker (or the default)."""
    return os.environ.get("LCM_DEFAULT_URL", "udpm://239.255.76.67:7667?ttl=0")


@pytest.fixture
def wait_until():
    """Poll a predicate until it's true or a timeout elapses. See dimos.utils.testing.waiting."""
    return _wait_until


@pytest.fixture
def retry_until():
    """Retry an action until a threading.Event fires. See dimos.utils.testing.waiting."""
    return _retry_until


@pytest.hookimpl(tryfirst=True)
def pytest_collection_modifyitems(config, items):
    _skipif_markers = {
        "skipif_in_ci": (bool(os.getenv("CI")), "Skipped in CI"),
        "skipif_no_openai": (not os.getenv("OPENAI_API_KEY"), "OPENAI_API_KEY not set"),
        "skipif_no_alibaba": (not os.getenv("ALIBABA_API_KEY"), "ALIBABA_API_KEY not set"),
        "skipif_no_ros": (not _has_ros(), "ROS dependencies are not present"),
        "skipif_macos_bug": (_is_macos(), "Some tests are buggy on Mac OS"),
        "skipif_macos": (_is_macos(), "Not intended to run on macOS"),
        "skipif_aarch64": (
            platform.machine() == "aarch64",
            "Not intended to run on aarch64 (Linux ARM)",
        ),
    }
    for marker_name, (condition, reason) in _skipif_markers.items():
        if condition:
            skip = pytest.mark.skip(reason=reason)
            for item in items:
                if item.get_closest_marker(marker_name):
                    item.add_marker(skip)


_session_threads = set()
_seen_threads = set()
_seen_threads_lock = threading.RLock()
_before_test_threads = {}  # Map test name to set of thread IDs before test


@pytest.fixture(scope="module")
def dimos_cluster():
    dimos = ModuleCoordinator()
    dimos.start()
    try:
        yield dimos
    finally:
        dimos.stop()


@pytest.hookimpl()
def pytest_sessionfinish(session):
    """Track threads that exist at session start - these are not leaks."""

    yield

    # Check for session-level thread leaks at teardown. A stopped thread that
    # lingers in the registry (e.g. a zenoh pyo3-closure thread awaiting reaping)
    # is not a leak, so only count threads that are still running.
    final_threads = [
        t
        for t in threading.enumerate()
        if t.name != "MainThread" and t.ident not in _session_threads and t.is_alive()
    ]

    if final_threads:
        thread_info = [f"{t.name} (daemon={t.daemon})" for t in final_threads]
        pytest.fail(
            f"\n{len(final_threads)} thread(s) leaked during test session: {thread_info}\n"
            "Session-scoped fixtures must clean up all threads in their teardown."
        )


@pytest.fixture(autouse=True)
def monitor_threads(request):
    # Capture threads before test runs
    test_name = request.node.nodeid
    with _seen_threads_lock:
        _before_test_threads[test_name] = {
            t.ident for t in threading.enumerate() if t.ident is not None
        }

    yield

    with _seen_threads_lock:
        before = _before_test_threads.get(test_name, set())

    # Threads intentionally left running for the whole process and cleaned up on
    # exit, so they don't count as per-test leaks.
    expected_persistent_thread_prefixes = [
        "Dask-Offload",
        # HuggingFace safetensors conversion thread - no user cleanup API
        # https://github.com/huggingface/transformers/issues/29513
        "Thread-auto_conversion",
    ]

    def live_new_threads():
        # Threads created during this test that are still running. A thread that
        # has already stopped is not a leak -- it's done, just not yet reaped
        # from threading's registry -- so we key on is_alive(), not presence.
        result = []
        for t in threading.enumerate():
            if t.ident is None or t.ident in before or t.name == "MainThread":
                continue
            if any(t.name.startswith(prefix) for prefix in expected_persistent_thread_prefixes):
                continue
            if t.is_alive():
                result.append(t)
        return result

    # Some C extensions tear their callback threads down asynchronously, so a
    # thread can stay alive briefly after the test cleaned up its owner (notably
    # zenoh's pyo3-closure threads, freed shortly after the session is closed).
    # A single snapshot races that teardown and flags a thread that is about to
    # exit. Give new threads a grace period to drain; only ones that stay alive
    # are real leaks (a genuinely leaked thread never exits).
    deadline = time.monotonic() + 5.0
    leaked = live_new_threads()
    while leaked and time.monotonic() < deadline:
        time.sleep(0.02)
        leaked = live_new_threads()

    if not leaked:
        return

    with _seen_threads_lock:
        # Report each leaked thread only once across the session.
        truly_new = [t for t in leaked if t.ident not in _seen_threads]
        for t in leaked:
            _seen_threads.add(t.ident)

    if not truly_new:
        return

    thread_names = [t.name for t in truly_new]

    pytest.fail(
        f"Non-closed threads created during this test. Thread names: {thread_names}. "
        "Please look at the first test that fails and fix that."
    )
